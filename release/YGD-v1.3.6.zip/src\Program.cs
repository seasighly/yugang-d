﻿// 壁纸 —— 独立视频壁纸宿主（桌面层）
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace WallpaperApp
{
    internal static class Program
    {
        public const string Version = "1.3.6";

        /// <summary>当前模式："idle" 躺床 / "work" 工作。</summary>
        public static string Mode = "idle";
        public static bool SelfTest = false;

        /// <summary>待创建壁纸窗口的屏幕列表（主窗口显示后逐个创建）。</summary>
        public static Screen[] PendingScreens;

        /// <summary>任务栏是否被本程序隐藏（隐藏时布局用整屏）。</summary>
        public static bool TaskbarHidden;

        public static System.Drawing.Rectangle AreaOf(Screen s)
        {
            return TaskbarHidden ? s.Bounds : s.WorkingArea;
        }

        [STAThread]
        private static void Main(string[] args)
        {
            // 单实例：已经在跑就不再起第二个
            bool createdNew;
            var mutex = new System.Threading.Mutex(true, "Global\\YGD_Wallpaper_SingleInstance", out createdNew);
            if (!createdNew) { return; }

            // 必须在建任何窗口之前：开启 per-monitor DPI 感知，否则坐标被虚拟化，
            // 窗口会比实际屏幕大 1.5 倍（150% 缩放时只显示局部）
            try { DpiAware.Enable(); } catch { }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length > 0 && args[0] == "--dsh") { Environment.SetEnvironmentVariable("DSH_AUTO", "1"); }
            if (Array.IndexOf(args, "--hide-taskbar") >= 0) { Program.TaskbarHidden = true; }
            if (Array.IndexOf(args, "--selftest") >= 0) { Program.SelfTest = true; Environment.SetEnvironmentVariable("DSH_AUTO", "1"); }

            // 多显示器：每块屏一个壁纸窗口，内容镜像
            var all = new System.Collections.Generic.List<Screen>(Screen.AllScreens);
            all.Sort(delegate(Screen a, Screen b) { return b.Primary.CompareTo(a.Primary); });
            var screens = all.ToArray();
            Program.Log("screens: " + screens.Length + " primary=" + screens[0].Bounds);

            SettingsD.LoadFromDisk();   // Main 里先读设置，预热前就要知道镜像与否
            // 确保任务栏状态与本程序记录一致（避免上次测试残留把任务栏藏了）
            DesktopHost.SetTaskbarVisible(!Program.TaskbarHidden);
            PendingScreens = screens;
            Application.Run(new WallWindow(screens[0], true, 0, false));
        }

        /// <summary>所有壁纸窗口（多屏）。</summary>
        public static readonly System.Collections.Generic.List<Screen> PaneScreens = new System.Collections.Generic.List<Screen>();

        public static readonly System.Collections.Generic.List<WallWindow> Windows =
            new System.Collections.Generic.List<WallWindow>();

        /// <summary>把模式同步到其它屏的窗口（瞬间切换，不播动画）。</summary>
        /// <summary>任务栏显隐后重算分屏布局并推给页面。</summary>
        private static string _lastLayoutSig = "";

        /// <summary>工作区变了（任务栏显隐等）就重推布局。</summary>
        public static void PushLayoutsIfChanged()
        {
            var sb = new System.Text.StringBuilder();
            foreach (var s in Screen.AllScreens)
            {
                var b = AreaOf(s);
                sb.Append(b.X + "," + b.Y + "," + b.Width + "," + b.Height + ";");
            }
            string sig = sb.ToString();
            if (sig == _lastLayoutSig) return;
            _lastLayoutSig = sig;
            PushLayouts();
        }

        public static void PushLayouts()
        {
            try
            {
                var vs = SystemInformation.VirtualScreen;
                var sb = new System.Text.StringBuilder("[");
                var scrs = Screen.AllScreens;
                PaneScreens.Clear();
                for (int i = 0; i < scrs.Length; i++)
                {
                    PaneScreens.Add(scrs[i]);
                    var b = AreaOf(scrs[i]);
                    if (i > 0) sb.Append(",");
                    sb.Append("{\"x\":" + (b.X - vs.X) + ",\"y\":" + (b.Y - vs.Y) +
                              ",\"w\":" + b.Width + ",\"h\":" + b.Height + "}");
                }
                sb.Append("]");
                foreach (var w in Windows) { if (w != null && !w.IsDisposed) w.RunJsPublic("window.__ygSetLayouts && window.__ygSetLayouts(" + sb + ")"); }
                Log("layouts pushed: " + sb);
            }
            catch (Exception ex) { Log("push layouts fail: " + ex.Message); }
        }

        public static void BroadcastMode(string mode, bool instant)
        {
            foreach (var w in Windows)
            {
                if (w == null || w.IsDisposed) continue;
                if (instant) w.SetModeInstant(mode == "work");
                else w.SetModeRemote(mode == "work");
            }
        }

        public static void Log(string m)
        {
            try
            {
                File.AppendAllText(
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wall.log"),
                    DateTime.Now.ToString("MM-dd HH:mm:ss") + "  " + m + Environment.NewLine);
            }
            catch { }
        }
    }

    internal sealed class WallWindow : Form
    {
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr h, int id, uint mods, uint vk);
        private const uint MOD_ALT = 1, MOD_CONTROL = 2;

        private bool skipFlag = false;
        private readonly Screen _screen;
        private readonly bool _primary;
        private readonly int _index;
        private readonly bool _mirrorOnly;
        private IntPtr _thumb;
        public static WallWindow Current;
        public bool Primary { get { return _primary; } }
        private readonly WebView2 _view;
        private readonly NotifyIcon _tray;

        /// <summary>让壁纸层播放"回床"动画（浮层关闭时调用）。</summary>
        public void GoIdleJs()
        {
            RunJs("window.__goIdle && window.__goIdle()");
        }

        /// <summary>设置窗口保存后调用，切换 JS 里的跳过动画标志。</summary>
        public void ApplySkip(bool on)
        {
            skipFlag = on;
            RunJs("window.__skipAnim = " + (on ? "true" : "false"));
        }

        public WallWindow(Screen screen, bool primary, int index, bool mirrorOnly)
        {
            _screen = screen;
            _index = index;
            _mirrorOnly = mirrorOnly;
            _primary = primary;
            Program.Windows.Add(this);
            if (primary) Current = this;
            Text = "鱼缸D";
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            Bounds = primary ? SystemInformation.VirtualScreen : screen.Bounds;
            BackColor = Color.Black;
            TopMost = false;

            try
            {
                string assets = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "web", "assets");
                if (!Directory.Exists(assets)) assets = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "web", "assets");
                MediaServer.Start(assets);
            }
            catch { }

            if (!_mirrorOnly)
            {
                _view = new WebView2 { Dock = DockStyle.Fill };
                Controls.Add(_view);
            }

            var menu = new ContextMenuStrip();
            if (!primary) { menu.Dispose(); }
            var tb = new ToolStripMenuItem("隐藏任务栏");
            tb.Click += delegate
            {
                tb.Checked = !tb.Checked;
                Program.TaskbarHidden = tb.Checked;
                DesktopHost.SetTaskbarVisible(!tb.Checked);
                var timer = new Timer { Interval = 600 };
                timer.Tick += delegate { timer.Stop(); timer.Dispose(); Program.PushLayouts(); };
                timer.Start();
            };
            menu.Items.Add(tb);
            menu.Items.Add("标定模式", null, delegate { RunJs("window.__calib(true)"); });
            var skip = new ToolStripMenuItem("跳过切换动画");
            skip.Click += delegate
            {
                skipFlag = !skipFlag;
                skip.Checked = skipFlag;
                RunJs("window.__skipAnim = " + (skipFlag ? "true" : "false"));
            };
            menu.Items.Add(skip);
            menu.Items.Add("重启浮层 DSH", null, delegate
            {
                try
                {
                    var c = System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties();
                    foreach (var pr in Process.GetProcessesByName("node"))
                    {
                        try
                        {
                            if (pr.Id != 0 && pr.MainWindowHandle == IntPtr.Zero) { }
                        }
                        catch { }
                    }
                }
                catch { }
                DshOverlay.RestartServer();
                DshOverlay.HideOverlay();
            });
            menu.Items.Add("重新加载", null, delegate { try { _view.CoreWebView2.Reload(); } catch { } });
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add("退出", null, delegate { Close(); });

            FormClosing += delegate
            {
                Program.Windows.Remove(this);
                if (_tray != null) { try { _tray.Visible = false; _tray.Dispose(); } catch { } }
            };

            if (primary)
            {
                Icon icon = null;
                try { icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
                _tray = new NotifyIcon();
                _tray.Icon = icon != null ? icon : SystemIcons.Application;
                _tray.Text = "鱼缸D";
                _tray.Visible = true;
                _tray.ContextMenuStrip = menu;
            }

            Shown += delegate
            {
                try { if (_primary) DshOverlay.Warmup(); } catch { }
                if (_primary)
                {
                    var layoutWatch = new Timer { Interval = 2000 };   // 任务栏显隐/分辨率变化时自动重排
                    layoutWatch.Tick += delegate { try { Program.PushLayoutsIfChanged(); } catch { } };
                    layoutWatch.Start();
                }
                if (_mirrorOnly)
                {
                    try
                    {
                        DesktopHost.Attach(Handle, _screen.Bounds);
                        Visible = true;
                        var pw = Program.Windows.Find(delegate(WallWindow x) { return x != null && x.Primary; });
                        if (pw != null && pw.Handle != IntPtr.Zero)
                        {
                            IntPtr th;
                            _thumb = IntPtr.Zero;
                            if (DwmThumb.Attach(Handle, pw.Handle, ClientSize, out th)) _thumb = th;
                        }
                    }
                    catch (Exception ex) { Program.Log("mirror attach fail: " + ex.Message); }
                    return;
                }

                if (_primary && Program.PendingScreens != null)
                {
                    // 单窗口横跨所有屏，页面里再切分画面（只解码一次）
                    AttachNow();
                }
            };

            if (Environment.GetEnvironmentVariable("DSH_AUTO") == "1")
            {
                Shown += delegate { DshOverlay.ShowOverlay(); };
            }

            Load += async delegate
            {
                if (_mirrorOnly) return;
                try
                {
                    string dataDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "profile-" + _index);
                    var env = await CoreWebView2Environment.CreateAsync(null, dataDir);
                    await _view.EnsureCoreWebView2Async(env);

                    // 把每块屏的位置（相对虚拟屏，物理像素）交给页面切分画布
                    var vs = Bounds;   // 以窗口自身矩形为基准，避免 VirtualScreen 原点不一致
                    var sb = new System.Text.StringBuilder("[");
                    var scrs = Screen.AllScreens;
                    Program.PaneScreens.Clear();
                    for (int i = 0; i < scrs.Length; i++)
                    {
                        Program.PaneScreens.Add(scrs[i]);   // 页面分屏顺序 == 这个顺序
                        var b = Program.AreaOf(scrs[i]);    // 任务栏可见时躲开它，隐藏时用整屏
                        if (i > 0) sb.Append(",");
                        sb.Append("{\"x\":" + (b.X - vs.X) + ",\"y\":" + (b.Y - vs.Y) +
                                  ",\"w\":" + b.Width + ",\"h\":" + b.Height + "}");
                    }
                    sb.Append("]");

                    int primaryIdx = 0;
                    for (int i = 0; i < scrs.Length; i++) if (scrs[i].Primary) { primaryIdx = i; break; }
                    try
                    {
                        await _view.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(
                            "window.__ygLayouts=" + sb + ";" +
                            "window.__ygPort=" + MediaServer.Port + ";" +
                            "window.__ygPrimary=" + primaryIdx + ";");
                        Program.Log("layouts injected: " + sb + " primaryIdx=" + primaryIdx + " winX=" + vs.X);
                    }
                    catch (Exception ex) { Program.Log("layout inject fail: " + ex.Message); }

                    var st = _view.CoreWebView2.Settings;
                    st.AreDefaultContextMenusEnabled = false;
                    st.IsStatusBarEnabled = false;

                    _view.CoreWebView2.WebMessageReceived += delegate (object a, CoreWebView2WebMessageReceivedEventArgs b)
                    {
                        try
                        {
                            string s = b.TryGetWebMessageAsString();
                            Program.Log("msg: " + s);
                            if (s == "mode:work" && Program.Mode != "work") { Program.Mode = "work"; }
                            if (s == "mode:idle" && Program.Mode != "idle") { Program.Mode = "idle"; }
                            if (s != null && s.StartsWith("open-dsh")) { int pi = -1; try { if (s.Length > 9) pi = int.Parse(s.Substring(9)); } catch { } DshOverlay.ShowOverlayIndex(pi); }
                            if (s == "close-dsh") { DshOverlay.HideOverlay(); RunJs("window.__goIdle && window.__goIdle()"); }
                            if (s == "open-settings")
                            {
                                var f = new SettingsD();
                                f.Show();
                            }
                            if (s != null && s.StartsWith("calib:"))
                            {
                                string dir = AppDomain.CurrentDomain.BaseDirectory;
                                string body = s.Substring(6);
                                File.WriteAllText(Path.Combine(dir, "calib-latest.txt"), body);
                                File.WriteAllText(
                                    Path.Combine(dir, "calib-" + DateTime.Now.ToString("MMdd-HHmmss") + ".txt"), body);
                                Program.Log("标定结果已保存到 calib.txt");
                            }
                        }
                        catch { }
                    };

                    _view.CoreWebView2.NavigationCompleted += async delegate
                    {
                        await System.Threading.Tasks.Task.Delay(1500);
                        try
                        {
                            string r = await _view.CoreWebView2.ExecuteScriptAsync("typeof window.__goIdle + '|' + typeof window.__skipAnim + '|' + typeof window.__playMode + '|' + typeof window.__setModeInstant");
                            Program.Log("wallpaper probe: " + r);
                        }
                        catch (Exception ex) { Program.Log("wallpaper probe fail: " + ex.Message); }
                    };

                    string html = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "web", "index.html");
                    if (!File.Exists(html))
                    {
                        string up = Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                        if (up != null) html = Path.Combine(up, "web", "index.html");
                    }
                    SettingsD.LoadFromDisk();
                    ApplySkip(SettingsD.SkipAnim);

                    _view.CoreWebView2.NavigationCompleted += delegate
                    {
                        ApplySkip(SettingsD.SkipAnim);   // 页面加载后补一次，确保标志生效
                    };
                    if (File.Exists(html)) _view.Source = new Uri("http://127.0.0.1:" + MediaServer.Port + "/index.html");
                    else Program.Log("找不到 web/index.html: " + html);
                }
                catch (Exception ex)
                {
                    Program.Log("init: " + ex);
                    Close();
                }
            };
        }

        /// <summary>挂到桌面层（可对任意屏窗口调用）。</summary>
        public void AttachNow()
        {
            try { DesktopHost.Attach(Handle, Bounds); Visible = true; }
            catch (Exception ex) { Program.Log("attach now fail: " + ex.Message); }
        }

        /// <summary>其它屏播同一段动画（保持同步）。</summary>
        public void SetModeRemote(bool work)
        {
            RunJs("window.__playMode && window.__playMode(" + (work ? "true" : "false") + ")");
        }

        /// <summary>其它屏同步模式（瞬间，不播动画）。</summary>
        public void SetModeInstant(bool work)
        {
            RunJs("window.__setModeInstant && window.__setModeInstant(" + (work ? "true" : "false") + ")");
        }

        public void RunJsPublic(string js) { RunJs(js); }

        private void RunJs(string js) { try { if (_view != null && _view.CoreWebView2 != null) _view.CoreWebView2.ExecuteScriptAsync(js); } catch { } }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);

            if (!_primary) return;
            bool q = RegisterHotKey(Handle, 2, MOD_CONTROL | MOD_ALT, 0x51);
            bool h = RegisterHotKey(Handle, 4, MOD_CONTROL | MOD_ALT, 0x48);
            bool d = RegisterHotKey(Handle, 5, MOD_CONTROL, 0x44);
            Program.Log("hotkeys Q=" + q + " H=" + h + " D=" + d);
        }

        /// <summary>把其它屏的鼠标事件换算成比例坐标，转给主屏页面。</summary>
        private void ForwardPointer(string type, int x, int y)
        {
            try
            {
                var pw = Program.Windows.Find(delegate(WallWindow v) { return v != null && v.Primary; });
                if (pw == null) return;
                double nx = ClientSize.Width > 0 ? (double)x / ClientSize.Width : 0;
                double ny = ClientSize.Height > 0 ? (double)y / ClientSize.Height : 0;
                pw.RunJs(string.Format(System.Globalization.CultureInfo.InvariantCulture,
                    "window.__remotePointer && window.__remotePointer('{0}',{1:F5},{2:F5})", type, nx, ny));
            }
            catch { }
        }

        protected override void WndProc(ref Message m)
        {
            if (_mirrorOnly && (m.Msg == 0x0200 || m.Msg == 0x0201))
            {
                int lp = m.LParam.ToInt32();
                int mx = (short)(lp & 0xFFFF);
                int my = (short)((lp >> 16) & 0xFFFF);
                ForwardPointer(m.Msg == 0x0201 ? "click" : "move", mx, my);
                base.WndProc(ref m);
                return;
            }
            if (m.Msg == 0x0312)
            {
                int id = m.WParam.ToInt32();
                if (id == 2) { Close(); return; }
                if (id == 5) { DshOverlay.ToggleTopmost(); return; }
                if (id == 4) { Visible = !Visible; return; }
            }
            base.WndProc(ref m);
        }
    }
}

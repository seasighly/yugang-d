// DPI 感知：必须在创建任何窗口之前调用
using System;
using System.Runtime.InteropServices;

namespace WallpaperApp
{
    internal static class DpiAware
    {
        [DllImport("user32.dll")]
        private static extern bool SetProcessDpiAwarenessContext(IntPtr value);

        [DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();

        [DllImport("shcore.dll")]
        private static extern int SetProcessDpiAwareness(int value);

        public static void Enable()
        {
            // PER_MONITOR_AWARE_V2 = -4
            try { if (SetProcessDpiAwarenessContext(new IntPtr(-4))) { Program.Log("dpi: per-monitor v2"); return; } }
            catch { }

            try { if (SetProcessDPIAware()) { Program.Log("dpi: system aware"); return; } }
            catch { }

            try
            {
                int hr = SetProcessDpiAwareness(2); // PROCESS_PER_MONITOR_DPI_AWARE
                Program.Log("dpi: shcore result " + hr);
            }
            catch { Program.Log("dpi: none"); }
        }
    }
}

// DWM 缩略图：把主屏壁纸窗口的画面复制到其它屏幕，只解码一次
using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace WallpaperApp
{
    internal static class DwmThumb
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct RECT { public int left, top, right, bottom; }

        [StructLayout(LayoutKind.Sequential)]
        private struct DWM_THUMBNAIL_PROPERTIES
        {
            public int dwFlags;
            public RECT rcDestination;
            public RECT rcSource;
            public byte opacity;
            [MarshalAs(UnmanagedType.Bool)] public bool fVisible;
            [MarshalAs(UnmanagedType.Bool)] public bool fSourceClientAreaOnly;
        }

        private const int DWM_TNP_RECTDESTINATION = 0x1;
        private const int DWM_TNP_RECTSOURCE = 0x2;
        private const int DWM_TNP_OPACITY = 0x4;
        private const int DWM_TNP_VISIBLE = 0x8;
        private const int DWM_TNP_SOURCECLIENTAREAONLY = 0x10;

        [DllImport("dwmapi.dll")]
        private static extern int DwmRegisterThumbnail(IntPtr dest, IntPtr src, out IntPtr thumb);

        [DllImport("dwmapi.dll")]
        private static extern int DwmUnregisterThumbnail(IntPtr thumb);

        [DllImport("dwmapi.dll")]
        private static extern int DwmUpdateThumbnailProperties(IntPtr thumb, ref DWM_THUMBNAIL_PROPERTIES props);

        /// <summary>把 src 的画面贴到 dest 上，铺满客户区。返回是否成功。</summary>
        public static bool Attach(IntPtr dest, IntPtr src, Size size, out IntPtr thumb)
        {
            thumb = IntPtr.Zero;
            try
            {
                int hr = DwmRegisterThumbnail(dest, src, out thumb);
                if (hr != 0 || thumb == IntPtr.Zero)
                {
                    Program.Log("dwm register failed hr=" + hr);
                    return false;
                }

                var p = new DWM_THUMBNAIL_PROPERTIES();
                p.dwFlags = DWM_TNP_RECTDESTINATION | DWM_TNP_VISIBLE | DWM_TNP_OPACITY | DWM_TNP_SOURCECLIENTAREAONLY;
                p.rcDestination = new RECT { left = 0, top = 0, right = size.Width, bottom = size.Height };
                p.opacity = 255;
                p.fVisible = true;
                p.fSourceClientAreaOnly = true;

                hr = DwmUpdateThumbnailProperties(thumb, ref p);
                if (hr != 0)
                {
                    Program.Log("dwm update failed hr=" + hr);
                    return false;
                }
                Program.Log("dwm thumbnail attached " + size);
                return true;
            }
            catch (Exception ex)
            {
                Program.Log("dwm attach error: " + ex.Message);
                return false;
            }
        }
    }
}

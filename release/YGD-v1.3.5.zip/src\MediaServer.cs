﻿// 极简 HTTP 文件服务（TcpListener 实现，无需管理员权限）
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace WallpaperApp
{
    internal static class MediaServer
    {
        private const int BasePort = 3477;
        public static int Port { get; private set; }
        private static string _root;
        private static TcpListener _listener;

        public static void Start(string root)
        {
            if (_listener != null) return;
            _root = root;
            // 端口可能被 zombie 监听占住，逐个往后试
            for (int p = BasePort; p < BasePort + 20; p++)
            {
                try
                {
                    var l = new TcpListener(IPAddress.Loopback, p);
                    l.Start();
                    _listener = l;
                    Port = p;
                    var th = new Thread(AcceptLoop) { IsBackground = true };
                    th.Start();
                    Program.Log("media server on " + p + " root=" + root);
                    return;
                }
                catch { }
            }
            Program.Log("media server: no free port in range");
        }

        private static void AcceptLoop()
        {
            while (true)
            {
                TcpClient client;
                try { client = _listener.AcceptTcpClient(); }
                catch { break; }
                ThreadPool.QueueUserWorkItem(delegate { Handle(client); });
            }
        }

        private static string _balJson = "{\"ok\":false}";
        private static DateTime _balAt = DateTime.MinValue;

        /// <summary>查 DeepSeek 余额，60 秒缓存。</summary>
        private static string BalanceJson()
        {
            if ((DateTime.Now - _balAt).TotalSeconds < 60 && _balJson != null) return _balJson;
            try
            {
                string key = Environment.GetEnvironmentVariable("DEEPSEEK_API_KEY", EnvironmentVariableTarget.User);
                if (string.IsNullOrEmpty(key)) key = Environment.GetEnvironmentVariable("DEEPSEEK_API_KEY");
                if (string.IsNullOrEmpty(key))
                {
                    _balJson = "{\"ok\":false,\"error\":\"no-key\"}";
                    _balAt = DateTime.Now;
                    return _balJson;
                }

                var req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create("https://api.deepseek.com/user/balance");
                req.Proxy = null;
                req.Timeout = 8000;
                req.Headers.Add("Authorization", "Bearer " + key);

                using (var resp = (System.Net.HttpWebResponse)req.GetResponse())
                using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                {
                    string body = sr.ReadToEnd();
                    _balJson = "{\"ok\":true,\"at\":\"" + DateTime.Now.ToString("HH:mm:ss") + "\",\"raw\":" + body + "}";
                }
            }
            catch (Exception ex)
            {
                _balJson = "{\"ok\":false,\"error\":\"" + ex.Message.Replace("\"", "'") + "\"}";
            }
            _balAt = DateTime.Now;
            Program.Log("balance: " + _balJson.Substring(0, Math.Min(80, _balJson.Length)));
            return _balJson;
        }

        private static string _dshCookie;
        private static DateTime _dshCookieAt = DateTime.MinValue;

        /// <summary>用日志里的 token 换一张 DSH 登录 cookie。</summary>
        private static string DshCookie()
        {
            if (_dshCookie != null && (DateTime.Now - _dshCookieAt).TotalMinutes < 30) return _dshCookie;
            try
            {
                string log = @"C:\鱼池\logs\dsh-331.log";
                string tokUrl = null;
                if (File.Exists(log))
                {
                    using (var fs = new FileStream(log, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    using (var sr = new StreamReader(fs, Encoding.UTF8))
                    {
                        string all = sr.ReadToEnd();
                        var ms = Regex.Matches(all, @"http://\S+\?token=[A-Za-z0-9_\-]+");
                        if (ms.Count > 0) tokUrl = ms[ms.Count - 1].Value;
                    }
                }
                if (tokUrl == null) return null;

                var req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(tokUrl);
                req.Proxy = null;
                req.AllowAutoRedirect = false;
                req.Timeout = 8000;
                try
                {
                    using (var resp = (System.Net.HttpWebResponse)req.GetResponse()) { _dshCookie = resp.Headers["Set-Cookie"]; }
                }
                catch (System.Net.WebException wex)
                {
                    var r = wex.Response as System.Net.HttpWebResponse;
                    if (r != null) _dshCookie = r.Headers["Set-Cookie"];
                }
                if (_dshCookie != null)
                {
                    _dshCookie = _dshCookie.Split(';')[0];
                    _dshCookieAt = DateTime.Now;
                    Program.Log("dsh cookie ok");
                }
            }
            catch (Exception ex) { Program.Log("dsh cookie fail: " + ex.Message); }
            return _dshCookie;
        }

        /// <summary>把 /dsh-whale/* 转发到 DSH 331。</summary>
        private static Tuple<string, byte[], string> ProxyDsh(string path, bool post, string body)
        {
            string cookie = DshCookie();
            var req = (System.Net.HttpWebRequest)System.Net.WebRequest.Create("http://127.0.0.1:331/" + path);
            req.Proxy = null;
            req.Timeout = 15000;
            req.Method = post ? "POST" : "GET";
            if (cookie != null) req.Headers.Add("Cookie", cookie);
            if (post)
            {
                byte[] bb = Encoding.UTF8.GetBytes(body ?? "");
                req.ContentType = "application/json";
                req.ContentLength = bb.Length;
                using (var s = req.GetRequestStream()) s.Write(bb, 0, bb.Length);
            }

            try
            {
                using (var resp = (System.Net.HttpWebResponse)req.GetResponse())
                using (var ms = new MemoryStream())
                {
                    resp.GetResponseStream().CopyTo(ms);
                    string ct = resp.ContentType ?? "application/json";
                    return Tuple.Create((int)resp.StatusCode + " OK", ms.ToArray(), ct);
                }
            }
            catch (System.Net.WebException wex)
            {
                var r = wex.Response as System.Net.HttpWebResponse;
                if (r != null)
                {
                    using (var ms = new MemoryStream())
                    {
                        r.GetResponseStream().CopyTo(ms);
                        return Tuple.Create((int)r.StatusCode + " ERR", ms.ToArray(), r.ContentType ?? "application/json");
                    }
                }
                throw;
            }
        }

        private static void Handle(TcpClient client)
        {
            try
            {
                using (client)
                using (var ns = client.GetStream())
                {
                    var buf = new byte[4096];
                    int read = ns.Read(buf, 0, buf.Length);
                    if (read <= 0) return;

                    string req = Encoding.ASCII.GetString(buf, 0, read);
                    string path = "/";
                    var parts = req.Split(' ');
                    if (parts.Length > 1) path = parts[1].TrimStart('/');

                    // /balance → 用本机 API Key 向 DeepSeek 查余额（缓存 60 秒）
                    if (path.StartsWith("balance"))
                    {
                        string json = BalanceJson();
                        byte[] bd = Encoding.UTF8.GetBytes(json);
                        string bh = "HTTP/1.1 200 OK\r\nContent-Type: application/json; charset=utf-8\r\n" +
                                    "Content-Length: " + bd.Length +
                                    "\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
                        byte[] hbh = Encoding.ASCII.GetBytes(bh);
                        ns.Write(hbh, 0, hbh.Length);
                        ns.Write(bd, 0, bd.Length);
                        return;
                    }

                    // /dsh-whale/* → 转发给 DSH 331（带登录 cookie），小鲸鱼挂件的原生接口
                    if (path.StartsWith("dsh-whale/"))
                    {
                        try
                        {
                            int hdrEnd = req.IndexOf("\r\n\r\n");
                            string reqHead = hdrEnd >= 0 ? req.Substring(0, hdrEnd) : req;
                            string body = hdrEnd >= 0 && req.Length > hdrEnd + 4 ? req.Substring(hdrEnd + 4) : "";

                            int contentLength = 0;
                            foreach (var line in reqHead.Split('\n'))
                                if (line.ToLower().StartsWith("content-length:"))
                                    int.TryParse(line.Split(':')[1].Trim(), out contentLength);
                            while (body.Length < contentLength && contentLength < 8 * 1024 * 1024)
                            {
                                int n2 = ns.Read(buf, 0, buf.Length);
                                if (n2 <= 0) break;
                                body += Encoding.UTF8.GetString(buf, 0, n2);
                            }

                            var pr = ProxyDsh(path, req.StartsWith("POST"), body);
                            Program.Log("proxy " + path + " -> " + pr.Item1);
                            byte[] pb = pr.Item2;
                            string ph = "HTTP/1.1 " + pr.Item1 + "\r\nContent-Type: " + pr.Item3 + "\r\n" +
                                        "Content-Length: " + pb.Length +
                                        "\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
                            byte[] phb = Encoding.ASCII.GetBytes(ph);
                            ns.Write(phb, 0, phb.Length);
                            ns.Write(pb, 0, pb.Length);
                        }
                        catch (Exception ex)
                        {
                            byte[] eb = Encoding.UTF8.GetBytes("{\"ok\":false,\"error\":\"" + ex.Message.Replace("\"", "'") + "\"}");
                            string eh = "HTTP/1.1 502 Bad Gateway\r\nContent-Type: application/json\r\nContent-Length: " + eb.Length +
                                        "\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n";
                            byte[] ehb = Encoding.ASCII.GetBytes(eh);
                            ns.Write(ehb, 0, ehb.Length);
                            ns.Write(eb, 0, eb.Length);
                        }
                        return;
                    }

                    string file = Path.Combine(_root, path.Replace("..", ""));
                    if (!File.Exists(file))
                    {
                        // 回退一层：/assets/xxx 之类指向 web/ 下的文件
                        string alt = Path.Combine(Path.GetDirectoryName(_root.TrimEnd(Path.DirectorySeparatorChar)) ?? _root, path.Replace("..", ""));
                        if (File.Exists(alt)) file = alt;
                    }
                    if (!File.Exists(file))
                    {
                        byte[] nf = Encoding.ASCII.GetBytes("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n");
                        ns.Write(nf, 0, nf.Length);
                        return;
                    }

                    byte[] data = File.ReadAllBytes(file);
                    string ext = Path.GetExtension(file).ToLowerInvariant();
                    string ct;
                    switch (ext)
                    {
                        case ".mp4": ct = "video/mp4"; break;
                        case ".html": ct = "text/html; charset=utf-8"; break;
                        case ".js": ct = "application/javascript; charset=utf-8"; break;
                        case ".css": ct = "text/css; charset=utf-8"; break;
                        case ".json": ct = "application/json; charset=utf-8"; break;
                        case ".png": ct = "image/png"; break;
                        case ".gif": ct = "image/gif"; break;
                        case ".jpg": ct = "image/jpeg"; break;
                        case ".svg": ct = "image/svg+xml"; break;
                        case ".mp3": ct = "audio/mpeg"; break;
                        case ".wav": ct = "audio/wav"; break;
                        case ".ico": ct = "image/x-icon"; break;
                        default: ct = "application/octet-stream"; break;
                    }
                    string head = "HTTP/1.1 200 OK\r\nContent-Type: " + ct +
                                  "\r\nContent-Length: " + data.Length +
                                  "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
                    byte[] hb = Encoding.ASCII.GetBytes(head);
                    ns.Write(hb, 0, hb.Length);
                    ns.Write(data, 0, data.Length);
                }
            }
            catch (Exception ex) { Program.Log("media handle: " + ex.Message); }
        }
    }
}

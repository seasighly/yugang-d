﻿// 鱼缸D 的 DSH 浮层：全屏、半透明、纯净 profile（无插件）
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace WallpaperApp
{
    internal sealed class DshOverlay : Form
    {
        private const int Port = 331;   // 直接用主 DSH，不再单独起一份
        private static readonly string LogPath =
            @"C:\鱼池\logs\dsh-331.log";

        private readonly WebView2 _view;
        private readonly Screen _screen;
        private static readonly System.Collections.Generic.Dictionary<string, DshOverlay> _wins =
            new System.Collections.Generic.Dictionary<string, DshOverlay>();
        private bool _warmed;
        private string _bgMode = "";
        private bool _inUse;        // 用户正在看
        private bool _videoReady;
        private bool _topmost;
        private bool _wasHiddenBeforeTop;
        private static readonly DateTime T0 = DateTime.Now;

        /// <summary>取（必要时创建）某块屏上的浮窗实例。</summary>
        private static DshOverlay Get(Screen screen, bool warm)
        {
            string key = screen.DeviceName;
            DshOverlay f;
            if (_wins.TryGetValue(key, out f) && f != null && !f.IsDisposed) return f;

            f = new DshOverlay(screen);
            _wins[key] = f;
            f.Bounds = Program.AreaOf(screen);
            f.Show();          // 需要可见句柄，否则 WebView2 会把视频挂起
            f.Opacity = 0.0;
            if (warm)
            {
                var w = new Timer { Interval = 9000 };
                w.Tick += delegate { w.Stop(); w.Dispose(); f.HideIfWarm(); };
                w.Start();
            }
            Program.Log("overlay window for " + key + " (" + screen.Bounds + ")");
            return f;
        }

        private static Screen[] Targets(Screen trigger)
        {
            // 只做单屏：点哪块屏就开在哪块；没指定就用主屏
            return new[] { trigger ?? Screen.FromPoint(Cursor.Position) };
        }

        /// <summary>开机预热：至少主屏一个实例；镜像模式下每块屏都建。</summary>
        public static void Warmup()
        {
            try
            {
                Get(Screen.PrimaryScreen, true);
                Program.Log("overlay warmup " + (DateTime.Now - T0).TotalMilliseconds.ToString("F0") + "ms");
            }
            catch (Exception ex) { Program.Log("warmup fail: " + ex.Message); }
        }

        public static void ShowOverlay(Screen screen = null)
        {
            try
            {
                foreach (var s in Targets(screen))
                {
                    var f = Get(s, false);
                    f._inUse = true;
                    f.Show();
                    f.Bounds = Program.AreaOf(s);
                    f.ApplyMode(Program.Mode);
                    f.ResumeVideo();
                    if (f._faded) f.Opacity = 1.0;
                    else if (f._videoReady) f.StartFade();
                    if (!f._topmost) f.AttachToDesktop();
                }
                Program.Log("overlay show on " + (screen ?? Screen.FromPoint(Cursor.Position)).DeviceName);
            }
            catch (Exception ex) { Program.Log("overlay show fail: " + ex.Message); }
        }

        /// <summary>按页面里的分屏序号决定显示在哪块屏。</summary>
        public static void ShowOverlayIndex(int paneIndex)
        {
            Screen sc = null;
            try
            {
                if (paneIndex >= 0 && paneIndex < Program.PaneScreens.Count) sc = Program.PaneScreens[paneIndex];
            }
            catch { }
            if (sc == null) sc = Screen.FromPoint(Cursor.Position);
            Program.Log("overlay target screen = " + sc.DeviceName + " (pane " + paneIndex + ")");
            ShowOverlay(sc);
        }

        /// <summary>Ctrl+D：桌面层 ↔ 最上层 切换；隐藏时按下则直接置顶显示。</summary>
        public static void ToggleTopmost()
        {
            try
            {
                var all = new System.Collections.Generic.List<DshOverlay>(_wins.Values);
                bool anyVisible = all.Exists(delegate(DshOverlay w) { return w != null && !w.IsDisposed && w.Visible; });

                if (!anyVisible)
                {
                    foreach (var s in new[] { Screen.PrimaryScreen })
                    {
                        var f = Get(s, false);
                        f._inUse = true;
                        f._wasHiddenBeforeTop = true;   // 记住：这次是被热键从"壁纸模式"拉起来的
                        f.Show();                 // 先显示，再置顶；顺序反了会被 Show 重置
                        f.Bounds = Program.AreaOf(s);
                        f.Opacity = 1.0;
                        f.ApplyMode(Program.Mode);
                        f.ResumeVideo();
                        f.SetTopmost(true);
                    }
                    Program.Log("hotkey: show topmost (from hidden)");
                    return;
                }

                bool wasTop = all.Exists(delegate(DshOverlay w) { return w != null && !w.IsDisposed && w.Visible && w.TopMost; });
                bool cameFromHidden = all.Exists(delegate(DshOverlay w) { return w != null && !w.IsDisposed && w._wasHiddenBeforeTop; });

                foreach (var w in all)
                {
                    if (w == null || w.IsDisposed || !w.Visible) continue;
                    if (wasTop)
                    {
                        if (cameFromHidden)
                        {
                            // 热键拉起来的 → 收回去，回到壁纸模式
                            w._inUse = false;
                            w._wasHiddenBeforeTop = false;
                            w.SetTopmost(false);
                            w.PauseVideo();
                            w.Hide();
                        }
                        else
                        {
                            // 工作模式里拉起来的 → 只回桌面层，仍然显示
                            w.SetTopmost(false);
                            w.AttachToDesktop();
                        }
                    }
                    else w.SetTopmost(true);
                }
                Program.Log("hotkey: " + (wasTop ? (cameFromHidden ? "hide (back to wallpaper)" : "back to desktop layer") : "topmost"));
            }
            catch (Exception ex) { Program.Log("hotkey fail: " + ex.Message); }
        }

        /// <summary>显示时把背景视频恢复播放（隐藏时被暂停过）。</summary>
        private void ResumeVideo()
        {
            try
            {
                if (_view != null && _view.CoreWebView2 != null)
                    _view.CoreWebView2.ExecuteScriptAsync(
                        "(function(){var v=document.getElementById('yg-bg');if(v&&v.paused)v.play().catch(function(){});})()");
            }
            catch { }
        }

        /// <summary>隐藏时把视频停掉，别在后台白烧 GPU。</summary>
        private void PauseVideo()
        {
            try
            {
                if (_view != null && _view.CoreWebView2 != null)
                    _view.CoreWebView2.ExecuteScriptAsync(
                        "(function(){var v=document.getElementById('yg-bg');if(v)v.pause();})()");
            }
            catch { }
        }

        /// <summary>把浮窗挂进桌面层，并压在壁纸之上、其它窗口之下。</summary>
        private void AttachToDesktop()
        {
            try { DesktopHost.Attach(Handle, Bounds); }
            catch (Exception ex) { Program.Log("overlay attach fail: " + ex.Message); }
        }

        private void SetTopmost(bool on)
        {
            _topmost = on;
            try
            {
                if (on)
                {
                    DesktopHost.Detach(Handle, Bounds);
                    TopMost = true;
                    BringToFront();
                    Activate();
                }
                else
                {
                    TopMost = false;
                }
            }
            catch (Exception ex) { Program.Log("topmost fail: " + ex.Message); }
        }

        /// <summary>预热完毕且没人在看就藏起来，别挡住桌面点击。</summary>
        private void HideIfWarm()
        {
            try { if (!_inUse && !IsDisposed) { PauseVideo(); Hide(); } } catch { }
        }

        public static void HideOverlay()
        {
            foreach (var w in _wins.Values)
            {
                if (w == null || w.IsDisposed) continue;
                w._inUse = false;
                w.PauseVideo();
                w.Hide();
            }
        }

        /// <summary>模式变了就换底下的视频，窗口本身不重建。</summary>
        private void ApplyMode(string mode)
        {
            if (_bgMode == mode) return;
            _bgMode = mode;
            try
            {
                if (_view.CoreWebView2 != null)
                    _view.CoreWebView2.ExecuteScriptAsync(
                        "window.__ygSetMode && window.__ygSetMode('" + mode + "')");
            }
            catch { }
        }

        private DshOverlay(Screen screen)
        {
            _screen = screen;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            Bounds = SystemInformation.VirtualScreen;
            BackColor = Color.Black;
            Opacity = 0.0;

            _view = new WebView2
            {
                Dock = DockStyle.Fill,
                DefaultBackgroundColor = Color.Transparent
            };
            Controls.Add(_view);

            KeyPreview = true;
            KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Escape) { Hide(); if (WallWindow.Current != null) WallWindow.Current.GoIdleJs(); }
            };

            if (!_warmed)
            {
                _warmed = true;
                // 首次显示才等视频；预热时不淡入
                var guard = new Timer { Interval = 6000 };
                guard.Tick += delegate
                {
                    guard.Stop();
                    guard.Dispose();
                    if (IsDisposed || Disposing || !Visible) return;
                    StartFade();
                };
                guard.Start();
                _guard = guard;
            }

            FormClosed += delegate
            {
                try { _wins.Remove(_screen.DeviceName); } catch { }
                try { if (_guard != null) { _guard.Stop(); _guard.Dispose(); _guard = null; } } catch { }
                _closing = true;
            };

            Load += async delegate
            {
                try
                {
                    string dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "profile-ov");
                    var env = await CoreWebView2Environment.CreateAsync(null, dir);
                    await _view.EnsureCoreWebView2Async(env);
                    _view.CoreWebView2.Settings.AreDevToolsEnabled = true;

                    _view.CoreWebView2.WebMessageReceived += delegate(object a, CoreWebView2WebMessageReceivedEventArgs b)
                    {
                        try
                        {
                            string s = b.TryGetWebMessageAsString();
                            if (s == "close-dsh") { HideOverlay(); if (WallWindow.Current != null) WallWindow.Current.GoIdleJs(); }
                            else if (s == "video-ready")
                            {
                                _videoReady = true;
                                Program.Log("video ready " + (DateTime.Now - T0).TotalMilliseconds.ToString("F0") + "ms");
                                if (_inUse) StartFade();
                                else { var hs = new Timer { Interval = 1500 }; hs.Tick += delegate { hs.Stop(); hs.Dispose(); HideIfWarm(); }; hs.Start(); }
                            }
                            else if (s == "video-error") { Program.Log("video error"); if (_inUse) StartFade(); }
                            else if (s != null && s.StartsWith("log:")) Program.Log("page " + s.Substring(4));
                        }
                        catch { }
                    };

                    string prefix = "window.__ygMode='" + Program.Mode + "';window.__ygPort=" + MediaServer.Port + ";";
                    await _view.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(prefix + Script);

                    if (Program.SelfTest)
                    {
                        _view.CoreWebView2.NavigationCompleted += async delegate
                        {
                            await System.Threading.Tasks.Task.Delay(1500);
                            try
                            {
                                string r = await _view.CoreWebView2.ExecuteScriptAsync(
                                    "(function(){var p=document.querySelector('#yg-hot .yg-hit');" +
                                    "if(!p)return 'no-hit';p.dispatchEvent(new MouseEvent('click',{bubbles:true}));return 'clicked';})()");
                                Program.Log("selftest click: " + r);
                            }
                            catch (Exception ex) { Program.Log("selftest fail: " + ex.Message); }
                        };
                    }

                    string url = EnsureDsh(false);
                    Program.Log("overlay url: " + url);
                    _view.Source = new Uri(url);
                }
                catch (Exception ex)
                {
                    Program.Log("overlay init: " + ex.Message);
                    Close();
                }
            };
        }

        private bool _faded;
        private bool _closing;
        private Timer _guard;

        /// <summary>视频出首帧后再淡入，避免"先黑一下"。</summary>
        private void StartFade()
        {
            if (_faded || _closing || IsDisposed || Disposing || !IsHandleCreated) return;
            _faded = true;
            var timer = new Timer { Interval = 20 };
            timer.Tick += delegate
            {
                try
                {
                    if (_closing || IsDisposed || Disposing || !IsHandleCreated)
                    {
                        timer.Stop(); timer.Dispose(); return;
                    }
                    Opacity = Math.Min(1.0, Opacity + 0.10);
                    if (Opacity >= 1.0) { timer.Stop(); timer.Dispose(); }
                }
                catch { try { timer.Stop(); timer.Dispose(); } catch { } }
            };
            timer.Start();
        }

        /// <summary>Transparent page over a looping video, matching the video-skin look.</summary>
        private const string Script = @"
(function(){
  function apply(){
    if(document.getElementById('yg-trans')) return;
    var s=document.createElement('style'); s.id='yg-trans';
    s.textContent = [
      'html,body{background:transparent !important}',
      'body{',
      '--dsw-alias-bg-base: rgba(21,21,23,0.20) !important;',
      '--dsw-alias-bg-layer-1: rgba(35,35,36,0.30) !important;',
      '--dsw-alias-bg-layer-2: rgba(41,41,41,0.36) !important;',
      '--dsw-alias-bg-layer-3: rgba(47,47,49,0.40) !important;',
      '--dsw-specific-sidebar-fill: rgba(27,27,28,0.26) !important;',
      '}',
      '.dshwv-snapmask{display:none !important}',
      '.dshwv-root{position:fixed !important;right:18px !important;bottom:18px !important}'
    ].join('');
    document.head.appendChild(s);
  }

  function bgVideo(){
    if(document.getElementById('yg-bg')) return;
    var v=document.createElement('video');
    v.id='yg-bg';
    v.src='http://127.0.0.1:' + (window.__ygPort || 3477) + '/' + (window.__ygMode === 'work' ? 'desk.mp4' : 'bed.mp4');
    v.addEventListener('loadeddata', function(){ try{ window.chrome.webview.postMessage('video-ready'); }catch(e){} });
    v.addEventListener('error', function(){ try{ window.chrome.webview.postMessage('video-error'); }catch(e){} });
    v.autoplay=true; v.muted=true; v.loop=true; v.playsInline=true;
    v.style.cssText='position:fixed;left:0;top:0;width:100%;height:100%;object-fit:cover;z-index:-1;pointer-events:none;';
    document.body.insertBefore(v, document.body.firstChild);

    // 模式切换：只换视频源，不重建页面
    window.__ygSetMode = function(mode){
      if (window.__ygMode === mode) return;
      window.__ygMode = mode;
      var el=document.getElementById('yg-bg');
      if(!el) return;
      el.src='http://127.0.0.1:' + (window.__ygPort || 3477) + '/' + (mode === 'work' ? 'desk.mp4' : 'bed.mp4');
      el.play();
    };
  }

  function hotspots(){
    if(document.getElementById('yg-hot')) return;
    var ns='http://www.w3.org/2000/svg';
    var svg=document.createElementNS(ns,'svg');
    svg.id='yg-hot';
    svg.setAttribute('viewBox','0 0 1600 914');
    svg.setAttribute('preserveAspectRatio','none');
    svg.style.cssText='position:fixed;z-index:2147483646;pointer-events:none;overflow:visible;';

    function fit(){
      var w=innerWidth, h=innerHeight;
      var s=Math.max(w/1600, h/914);
      var dw=1600*s, dh=914*s;
      svg.style.width=dw+'px';
      svg.style.height=dh+'px';
      svg.style.left=((w-dw)/2)+'px';
      svg.style.top=((h-dh)/2)+'px';
    }
    fit();
    addEventListener('resize', fit);

    var style=document.createElement('style');
    style.textContent = [
      '.yg-visual{fill:transparent;stroke:transparent;stroke-width:3;stroke-linejoin:round;',
      'vector-effect:non-scaling-stroke;pointer-events:none;transition:fill .25s ease,stroke .25s ease;}',
      '.yg-visual.hl{fill:rgba(120,200,255,0.10);stroke:rgba(165,225,255,0.95);',
      'filter:drop-shadow(0 0 6px rgba(120,200,255,0.9)) drop-shadow(0 0 16px rgba(90,170,255,0.55));}',
      '.yg-hit{fill:transparent;stroke:transparent;cursor:pointer;pointer-events:auto;}',
      '.yg-path{fill:transparent;stroke:transparent;stroke-width:3;cursor:pointer;stroke-linejoin:round;',
      'vector-effect:non-scaling-stroke;pointer-events:auto;transition:fill .25s ease,stroke .25s ease;}',
      '.yg-path:hover{fill:rgba(120,200,255,0.10);stroke:rgba(165,225,255,0.95);',
      'filter:drop-shadow(0 0 6px rgba(120,200,255,0.9)) drop-shadow(0 0 16px rgba(90,170,255,0.55));}'
    ].join('');
    document.head.appendChild(style);

    var BED_VISUAL = 'M156,762 L211,876 L389,796 L440,889 L963,623 L970,583 L981,588 L988,518 L906,431 L907,415 L851,365 L840,363 L779,311 L684,338 L643,336 L630,345 L612,366 L417,440 L373,376 L301,440 L260,457 L243,475 L215,486 L225,508 L132,543 L86,440 L66,446 L153,759 Z';
    var BED_HIT = 'M251,870 L423,791 L327,588 L443,477 L374,385 L220,496 L224,515 L138,553 L251,870 L425,790 L359,657 L379,537 Z';
    var BOOK = 'M339,841 L397,865 L406,877 L389,913 L297,913 L338,846 Z';

    var visual = document.createElementNS(ns,'path');
    visual.setAttribute('class','yg-visual');
    visual.setAttribute('d', BED_VISUAL);
    svg.appendChild(visual);

    var hit = document.createElementNS(ns,'path');
    hit.setAttribute('class','yg-hit');
    hit.setAttribute('d', BED_HIT);
    hit.addEventListener('mouseenter', function(){ visual.classList.add('hl'); });
    hit.addEventListener('mouseleave', function(){ visual.classList.remove('hl'); });
    hit.addEventListener('click', function(){ try{ window.chrome.webview.postMessage('close-dsh'); }catch(e){} });
    svg.appendChild(hit);

    var book = document.createElementNS(ns,'path');
    book.setAttribute('class','yg-path');
    book.setAttribute('d', BOOK);
    book.addEventListener('click', function(){ try{ window.chrome.webview.postMessage('open-settings'); }catch(e){} });
    svg.appendChild(book);

    document.body.appendChild(svg);
  }

  function probe(){
    setTimeout(function(){
      try{
        var v=document.getElementById('yg-bg');
        var msg='mode=' + window.__ygMode +
                ' video=' + (v ? (v.readyState + '/' + v.videoWidth + 'x' + v.videoHeight + ' t=' + v.currentTime.toFixed(1) + ' paused=' + v.paused) : 'MISSING') +
                ' svg=' + !!document.getElementById('yg-hot') +
                ' htmlBg=' + getComputedStyle(document.documentElement).backgroundColor;
        window.chrome.webview.postMessage('log:' + msg);
      }catch(e){ try{ window.chrome.webview.postMessage('log:probe-error ' + e.message); }catch(e2){} }
    }, 4000);
  }

  function newSession(){
    setTimeout(function(){
      try{
        var els=document.querySelectorAll('button, a, div[role=button]');
        for(var i=0;i<els.length;i++){
          var tx=(els[i].textContent||'').trim();
          if(tx==='新会话' || tx==='新对话'){
            els[i].click();
            window.chrome.webview.postMessage('log:clicked-new-session');
            return;
          }
        }
      }catch(e){}
    }, 2500);
  }

  function boot(){ apply(); bgVideo(); hotspots(); probe(); newSession(); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();";

        /// <summary>不再单独起 DSH：重启只是让浮窗重新拿一次 331 的 token 并刷新页面。</summary>
        public static void RestartServer()
        {
            try
            {
                string url = EnsureDsh(true);
                Program.Log("overlay reload: " + url);
                foreach (var w in _wins.Values)
                {
                    if (w == null || w.IsDisposed || w._view == null || w._view.CoreWebView2 == null) continue;
                    w._view.Source = new Uri(url);
                }
            }
            catch (Exception ex) { Program.Log("overlay reload fail: " + ex.Message); }
        }

        /// <summary>直接用正在运行的 331：只从日志里取 token，不拉起任何新进程。</summary>
        private static string EnsureDsh(bool force)
        {
            if (force) _liveUrl = null;
            var dl = DateTime.Now.AddSeconds(15);
            while (DateTime.Now < dl)
            {
                var url = TokenUrl();
                if (url != null) return url;
                if (!PortOpen(Port)) break;     // 主 DSH 没在跑，没必要等
                System.Threading.Thread.Sleep(300);
            }
            return "http://127.0.0.1:" + Port + "/";
        }

        private static string _liveUrl;

        private static string TokenUrl()
        {
            try
            {
                if (!File.Exists(LogPath)) return null;
                string text;
                using (var fs = new FileStream(LogPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var sr = new StreamReader(fs, Encoding.UTF8))
                    text = sr.ReadToEnd();
                var m = Regex.Matches(text, @"http://\S+\?token=[A-Za-z0-9_\-]+");
                if (m.Count > 0) return m[m.Count - 1].Value;
            }
            catch { }
            return null;
        }

        private static bool PortOpen(int port)
        {
            try
            {
                using (var c = new TcpClient())
                {
                    var t = c.BeginConnect("127.0.0.1", port, null, null);
                    if (!t.AsyncWaitHandle.WaitOne(300)) return false;
                    c.EndConnect(t);
                    return true;
                }
            }
            catch { return false; }
        }
    }
}

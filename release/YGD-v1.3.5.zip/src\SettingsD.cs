﻿// 鱼缸D 的设置窗口（从床头柜那本书打开）
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace WallpaperApp
{
    internal sealed class SettingsD : Form
    {
        private static readonly string IniPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "鱼缸D", "settings.ini");

        private readonly CheckBox _skip;

        public static bool SkipAnim { get; private set; }

        /// <summary>浮窗是否在所有屏幕镜像显示（false = 跟随点击的那块屏）。</summary>
        public static bool OverlayMirror { get; private set; }

        public static void LoadFromDisk()
        {
            try
            {
                if (!File.Exists(IniPath)) return;
                string all = File.ReadAllText(IniPath);
                SkipAnim = all.IndexOf("skip=1", StringComparison.Ordinal) >= 0;
                OverlayMirror = all.IndexOf("overlay=mirror", StringComparison.Ordinal) >= 0;
            }
            catch { }
        }

        public SettingsD()
        {
            Text = "鱼缸D · 设置";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(380, 250);
            BackColor = Color.FromArgb(18, 26, 38);
            ForeColor = Color.FromArgb(222, 234, 246);
            Font = new Font("Microsoft YaHei UI", 9.5f);

            _skip = new CheckBox
            {
                Text = "跳过切换动画（直接切换两个模式）",
                Left = 24, Top = 28, Width = 320, Height = 26,
                Checked = SkipAnim
            };
            Controls.Add(_skip);

            var lbl = new Label
            {
                Text = "浮窗固定显示在点击笔记本的那块屏幕；Ctrl+D 在主屏置顶",
                Left = 24, Top = 64, Width = 340, Height = 40,
                ForeColor = Color.FromArgb(150, 190, 230)
            };
            Controls.Add(lbl);

            var save = new Button
            {
                Text = "保存",
                Left = 24, Top = 150, Width = 140, Height = 36,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(43, 108, 176),
                ForeColor = Color.White
            };
            save.FlatAppearance.BorderSize = 0;
            save.Click += delegate
            {
                SkipAnim = _skip.Checked;
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(IniPath));
                    File.WriteAllText(IniPath, "skip=" + (SkipAnim ? "1" : "0") + "\noverlay=" + (OverlayMirror ? "mirror" : "follow") + "\n");
                }
                catch { }
                foreach (var win in Program.Windows) { if (win != null && !win.IsDisposed) win.ApplySkip(SkipAnim); }
                Close();
            };

            var close = new Button
            {
                Text = "关闭",
                Left = 190, Top = 150, Width = 100, Height = 36,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(40, 50, 64),
                ForeColor = Color.FromArgb(200, 214, 230)
            };
            close.FlatAppearance.BorderSize = 0;
            close.Click += delegate { Close(); };

            Controls.Add(save);
            Controls.Add(close);
        }
    }
}

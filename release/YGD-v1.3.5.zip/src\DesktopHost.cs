﻿// 把窗口挂到桌面层（WorkerW），并控制任务栏显隐
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace WallpaperApp
{
    internal static class DesktopHost
    {
        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr FindWindow(string cls, string win);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr FindWindowEx(IntPtr parent, IntPtr child, string cls, string win);

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam,
            uint flags, uint timeout, out IntPtr result);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr SetParent(IntPtr child, IntPtr parent);

        [DllImport("user32.dll")]
        private static extern IntPtr GetParent(IntPtr hWnd);

        [DllImport("user32.dll", EntryPoint = "GetWindowLongPtr")]
        private static extern IntPtr GetWindowLongPtr(IntPtr hWnd, int index);

        [DllImport("user32.dll", EntryPoint = "SetWindowLongPtr")]
        private static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int index, IntPtr value);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int cmd);

        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);

        private const int GWL_EXSTYLE = -20;
        private const long WS_EX_TOOLWINDOW = 0x00000080;
        private const long WS_EX_NOACTIVATE = 0x08000000;
        private const long WS_EX_APPWINDOW = 0x00040000;

        private static IntPtr _workerw;

        /// <summary>找到桌面的 WorkerW 层。找不到返回 IntPtr.Zero。</summary>
        private static IntPtr FindWorkerW()
        {
            if (_workerw != IntPtr.Zero) return _workerw;

            IntPtr progman = FindWindow("Progman", null);
            IntPtr result;
            // 让 Progman 生成 WorkerW
            SendMessageTimeout(progman, 0x052C, new IntPtr(0xD), new IntPtr(0x1), 0, 1000, out result);
            SendMessageTimeout(progman, 0x052C, new IntPtr(0xD), IntPtr.Zero, 0, 1000, out result);

            IntPtr workerw = IntPtr.Zero;
            EnumWindows_((top, l) =>
            {
                IntPtr shell = FindWindowEx(top, IntPtr.Zero, "SHELLDLL_DefView", null);
                if (shell != IntPtr.Zero)
                {
                    IntPtr w = FindWindowEx(IntPtr.Zero, top, "WorkerW", null);
                    if (w != IntPtr.Zero) { workerw = w; return false; }
                }
                return true;
            }, IntPtr.Zero);

            if (workerw == IntPtr.Zero)
            {
                // 兜底：Progman 自己
                workerw = progman;
            }
            _workerw = workerw;
            return _workerw;
        }

        private delegate bool EnumProc(IntPtr h, IntPtr l);
        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumProc cb, IntPtr l);
        private static void EnumWindows_(EnumProc cb, IntPtr l) { EnumWindows(cb, l); }

        /// <summary>挂到桌面层：不进 Alt+Tab，永远在最底下，不遮挡其他窗口。</summary>
        public static bool Attach(IntPtr hwnd, System.Drawing.Rectangle screenBounds)
        {
            try
            {
                long ex = GetWindowLongPtr(hwnd, GWL_EXSTYLE).ToInt64();
                ex |= WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
                ex &= ~WS_EX_APPWINDOW;
                SetWindowLongPtr(hwnd, GWL_EXSTYLE, new IntPtr(ex));

                IntPtr host = FindWorkerW();
                if (host != IntPtr.Zero)
                {
                    SetParent(hwnd, host);
                    var vs = SystemInformation.VirtualScreen;
                    SetWindowPos(hwnd, IntPtr.Zero,
                        screenBounds.X - vs.X, screenBounds.Y - vs.Y,
                        screenBounds.Width, screenBounds.Height,
                        0x0004 | 0x0040 | 0x0010);   // SHOWWINDOW|NOACTIVATE
                    Program.Log("attached to desktop: " + host + " rect=" + screenBounds);
                    return true;
                }
                SetWindowPos(hwnd, new IntPtr(1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010);
                Program.Log("attach fallback: bottom");
                return false;
            }
            catch (Exception ex)
            {
                Program.Log("attach fail: " + ex.Message);
                return false;
            }
        }

        /// <summary>从桌面层摘出来，恢复成普通顶层窗口。</summary>
        public static void Detach(IntPtr hwnd, System.Drawing.Rectangle rect)
        {
            try
            {
                SetParent(hwnd, IntPtr.Zero);
                SetWindowPos(hwnd, IntPtr.Zero, rect.X, rect.Y, rect.Width, rect.Height, 0x0004 | 0x0040);
                long ex = GetWindowLongPtr(hwnd, GWL_EXSTYLE).ToInt64();
                ex |= WS_EX_TOOLWINDOW;      // 仍然不进 Alt+Tab
                ex &= ~WS_EX_APPWINDOW;
                SetWindowLongPtr(hwnd, GWL_EXSTYLE, new IntPtr(ex));
                Program.Log("detached from desktop");
            }
            catch (Exception ex) { Program.Log("detach fail: " + ex.Message); }
        }

        /// <summary>显示/隐藏任务栏（含所有显示器）。</summary>
        public static void SetTaskbarVisible(bool visible)
        {
            int cmd = visible ? 5 : 0; // SW_SHOW / SW_HIDE
            IntPtr main = FindWindow("Shell_TrayWnd", null);
            if (main != IntPtr.Zero) ShowWindow(main, cmd);

            // 副屏任务栏
            IntPtr sec = IntPtr.Zero;
            do
            {
                sec = FindWindowEx(IntPtr.Zero, sec, "Shell_SecondaryTrayWnd", null);
                if (sec != IntPtr.Zero) ShowWindow(sec, cmd);
            } while (sec != IntPtr.Zero);

            Program.Log("taskbar visible=" + visible);
        }
    }
}
